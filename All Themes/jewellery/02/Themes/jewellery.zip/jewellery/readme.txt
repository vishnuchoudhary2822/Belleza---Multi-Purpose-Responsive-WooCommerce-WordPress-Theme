=== Corporate ===

Contributors: Multipurposethemes
Tags: editor-style, theme-options, custom-colors, custom-logo, footer-widgets

Requires at least: 4.0
Tested up to: 4.7
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.multipurposethemes.com

A starter theme called Corporate MTP.

== Description ==

Responsive Multipurpose Corporate Wordpress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any theme Options? =

Corporate MTP has Custom Color, Custom Logo and Google Font as theme options.

== Changelog ==

= 1.0 - May 02 2017 =
* Initial release

== Credits ==

* (C) 2017 Multipurposethemes (http://www.multipurposethemes.com)
